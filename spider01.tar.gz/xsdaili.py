import requests
from fake_useragent import UserAgent
from lxml import etree
import csv


class XiaoShuSpider(object):

    def __init__(self):
        self.url = 'http://www.xsdaili.com/dayProxy/ip/{}.html'
        self.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'}
        self.test_url = 'http://www.baidu.com'
        self.addr_list = []
        self.i = 0

    # 获取页面
    def get_html(self, url):
        html = requests.get(
            url=url, headers=self.headers
        ).content.decode('utf-8', 'ignore')
        return html

    # 解析页面
    def parse_html(self, url):
        html = self.get_html(url)
        xpath_bds = '//div[@class="col-md-12"]/div[@class="cont"]/text()'
        p_html = etree.HTML(html)
        ip_list = p_html.xpath(xpath_bds)
        for r in ip_list:
            addr = r.split('@')[0]
            self.test_addr(addr)

    # 测试代理IP
    def test_addr(self, addr):
        proxies = {
            'http': 'http://{}'.format(addr),
            'https': 'https://{}'.format(addr)
        }
        try:
            req = requests.get(
                url=self.test_url, headers=self.headers, proxies=proxies, timeout=3
            )

            code = req.status_code
            if code == 200:
                print('{}测试成功！'.format(addr))
                self.i += 1
                self.save_addr(addr)
        except Exception as e:
            pass

    # 保存到文件
    def save_addr(self, addr):

        # filename = 'IP.csv'
        # with open(filename, 'a') as f:
        #     writer = csv.writer(f)
        #     writer.writerow(self.addr_list)
        with open('pool/proxies.py', 'a') as fw:
            fw.write(str(addr) + '\r\n')

    # 入口函数
    def run(self):
        for i in range(1743, 1739, -2):
            url = self.url.format(i)
            self.parse_html(url)
        print('测试成功的ip共计： %s 个.' % self.i)


if __name__ == '__main__':
    spider = XiaoShuSpider()
    spider.run()
