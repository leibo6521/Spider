from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import pymongo
from lxml import etree


class XsbkSpider(object):

    def __init__(self):
        self.url = 'https://www.baidu.com/'
        self.options = webdriver.ChromeOptions()
        self.options.add_argument('--headless')
        self.driver = webdriver.Chrome(
            # options=self.options
        )
        self.conn = pymongo.MongoClient(
            'localhost', 27017
        )
        self.db = self.conn['qsdb']
        self.qscol= self.db['qscol']
        self.msg_list = []

    def jump_page(self):
        self.driver.get(self.url)
        ele = self.driver.find_element_by_id('kw')
        ele.send_keys('糗事百科')
        ele.send_keys(Keys.ENTER)
        time.sleep(3)
        self.driver.find_element_by_xpath('//*[@id="2"]/h3/a').click()
        all_handles = self.driver.window_handles
        self.driver.switch_to.window(all_handles[1])
        self.get_data()

    def get_data(self):
        while True:
            data_list = self.driver.find_elements_by_xpath('//*[@id="footzoon"]/div[@id="endtext"]')
            self.driver.execute_script(
                'window.scrollTo(0, document.body.scrollHeight)'
            )
            next_page = self.driver.page_source.find('下一页')
            if not next_page:
                break
            for data in data_list:
                self.msg_list.append(data.text)

    def run(self):
        self.jump_page()
        self.qscol.insert_many(self.msg_list)
        time.sleep(3)
        self.driver.quit()


if __name__ == '__main__':
    spider = XsbkSpider()
    spider.run()




