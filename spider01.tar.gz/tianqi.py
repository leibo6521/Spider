from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time


class TianqiSpider(object):

    def __init__(self):
        self.url = 'http://www.tianqi.com/'
        self.options = webdriver.ChromeOptions()
        self.options.add_argument('--headless')
        self.driver = webdriver.Chrome(
            options=self.options
        )

    def jump_page(self, city):
        self.driver.get(self.url)
        time.sleep(1)
        ipt = self.driver.find_element_by_xpath('//*[@id="index_serch"]/input')
        ipt.send_keys(city)
        time.sleep(1)
        ipt.send_keys(Keys.ENTER)
        time.sleep(1)
        self.get_data()

    def get_data(self):
        info = self.driver.find_element_by_class_name('weather_info').text
        msg_list = info.split('\n')
        for msg in msg_list:
            print(msg)

    def run(self):
        city = input('请输入您要查找的城市名： ')
        time.sleep(10)
        self.jump_page(city)


if __name__ == '__main__':
    spider = TianqiSpider()
    spider.run()
